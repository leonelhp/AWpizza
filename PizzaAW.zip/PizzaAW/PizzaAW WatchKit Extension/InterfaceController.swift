//
//  InterfaceController.swift
//  PizzaAW WatchKit Extension
//
//  Created by LEONEL HERNANDEZ PEREZ on 18/02/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    var wAux1:String = ""
    var wAux2:String = ""
    var wAux3:String = ""
    
    var listaTam = ["","Chica","Mediana","Grande"]
    var listaMas = ["","Delgada","Crujiente","Gruesa"]
    var listaque = ["","Mozarela","Chedar","Parmesano","Sin queso"]
    
    
    @IBOutlet var wTamaño: WKInterfaceLabel!
    @IBOutlet var wMasa: WKInterfaceLabel!
    @IBOutlet var wQueso: WKInterfaceLabel!
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    @IBAction func aTamaño(_ value: Int) {
        wTamaño.setText( listaTam[ value ] )
        wAux1=listaTam[ value ]
    }
    
    @IBAction func aMasa(_ value: Int) {
        wMasa.setText( listaMas[ value ])
        wAux2=listaTam[ value ]
    }
    
    @IBAction func aQueso(_ value: Int) {
        wQueso.setText( listaque[value] )
        wAux3=listaque[ value ]
    }
   
    @IBAction func aPasarOrden1() {
        let orden1 = Orden(t: wAux1, m: wAux2, q: wAux3)
        pushController(withName: "IdentificadorOrden", context: orden1)
    }
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
