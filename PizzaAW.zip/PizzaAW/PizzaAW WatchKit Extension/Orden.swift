//
//  Orden.swift
//  PizzaAW
//
//  Created by LEONEL HERNANDEZ PEREZ on 18/02/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import WatchKit

class Orden: NSObject {

    var oTam:String = ""
    var oMas:String = ""
    var oQue:String = ""
    
    init(t:String, m:String, q:String){
        oTam=t
        oMas=m
        oQue=q
    }
    
    
}
