//
//  vistaIngreidientes.swift
//  PizzaAW
//
//  Created by LEONEL HERNANDEZ PEREZ on 18/02/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import WatchKit
import Foundation


class vistaIngreidientes: WKInterfaceController {

    var wa1:String = ""
    var wa2:String = ""
    var wa3:String = ""
    
    @IBOutlet var wPep: WKInterfaceLabel!
    @IBOutlet var wPim: WKInterfaceLabel!
    @IBOutlet var wPiñ: WKInterfaceLabel!
    @IBOutlet var wJam: WKInterfaceLabel!
    @IBOutlet var wCeb: WKInterfaceLabel!
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        let c=context as! Orden
        print(c.oTam)
        
        wa1=c.oTam
        wa2=c.oMas
        wa3=c.oQue
        
        
        // Configure interface objects here.
    }


    
    
    @IBAction func aPep() {
        wPep.setText("Si")
    }
    
    @IBAction func aPim() {
        wPim.setText("Si")
    }
    @IBAction func sPiñ() {
        wPiñ.setText("Si")
    }
    
    @IBAction func aJam() {
        wJam.setText("Si")
    }
    
    @IBAction func aCeb() {
        wCeb.setText("Si")
    }
    
    @IBAction func aBorrar() {
        wPep.setText("-")
        wPim.setText("-")
        wPiñ.setText("-")
        wJam.setText("-")
        wCeb.setText("-")
        
            print(wa1)
    }
    
    @IBAction func apasa2() {
        let orden1 = Orden(t: wa1, m: wa2, q: wa3)
        pushController(withName: "IdentificadorOrden2", context: orden1)
        
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
